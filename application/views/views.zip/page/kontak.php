        <!-- main content -->
        <div class="main-content bottom-0 beranda">
            <div class="container">
                <!-- banner -->
                <div class="banner pad">
                    <!-- heading -->
                    <h2>Pondok Pesantren <br><span>Baitul  &amp; Qudus.</span></h2>
                    <!-- paragraph -->
                    <p>Pondok dengan sistem pendidikan yang unggul !!!</p>
                </div>
            </div>

            <!-- hero -->
            <div class="hero pad">
                <div class="container">
                    <div class="content">
                    <div class="benefits-item">
                    Anda juga bisa menghubungi pihak kami dengan nomor Wa di bawah ini !! <i class="fab fa-whatsapp"></i>
                    <h3>Nomor Wa <a href="https://api.whatsapp.com/send?phone=62895415019043">
                     0895415019043
                        </a></h3>
                        </div>
                        

                        <!-- heading -->
                        <h2>Lokasi</h2>
                        <!-- paragraph -->
                        <p>Buat anda yang ingin mondok lokasi pondok baitul qudus tepat seperti ini !!!</p>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d428.64777520812765!2d110.85029091700896!3d-6.780217301295666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e70dbdf9de65cff%3A0x176b386f69f3d374!2sGedung%20Serbaguna%20Kudus%20(LDII)!5e0!3m2!1sid!2sid!4v1627817427230!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        <!-- button -->
                        
                    </div>
                </div>
            </div>



            <!-- call to action -->
            <div class="cta">
                <div class="container">
                    <div class="cta-content">
                        <!-- heading -->
                        <h3></h3>
                        <p>Tales from those who follow the prelog way wherever it leads</p>
                    </div>
                </div>
            </div>




        </div>
