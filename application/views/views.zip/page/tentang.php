        <!-- main content -->
        <div class="main-content bottom-0 beranda">
            <div class="container">
                <!-- banner -->
                <div class="banner pad">
                    <!-- heading -->
                    <h2>Pondok Pesantren <br><span>Baitul  &amp; Qudus.</span></h2>
                    <!-- paragraph -->
                    <p>Pondok dengan sistem pendidikan yang unggul !!!</p>
                </div>
            </div>

            <!-- hero -->
            <div class="hero pad">
                <div class="container">
                    <div class="hero-content">
                        <!-- heading -->
                        <h2>Ayo Mondok yuk </h2>
                        <!-- paragraph -->
                        <p>Buat anda yang ingin mondok tekan link di bawah ini !!!</p>
                        <!-- button -->
                        <a href="<?= base_url('page/registration') ?>" class="btn btn-warning">Pendaftaran</a>
                    </div>
                </div>
            </div>



            <!-- call to action -->
            <div class="cta">
                <div class="container">
                    <div class="cta-content">
                        <!-- heading -->
                        <h3>Pondok Pesanten Baitul Qudus adalah Sebuah pondok yang berada di wilayah kabupaten Kudus Kecamatan Bae Desa Panjang dekat dengan masjid LDII kudus panjang, 
                        Pondok Pesantren Baituk Qudus didirikan pada tahun 2017 dengan pendiri dan ketua pondok sekitar dengan nama ketua pondok sebagai ketua Pondok Baitul Kudus  <span>PRELOG</span></h3>
                        <!-- paragraph -->
                        <p>Tales from those who follow the prelog way wherever it leads</p>
                    </div>
                </div>
            </div>




        </div>
