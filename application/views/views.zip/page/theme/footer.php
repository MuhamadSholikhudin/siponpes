<!-- footer -->
<footer>
    <div class="container">
        <!-- This theme comes under Creative Commons Attribution 4.0 Unported. So don't remove below link back -->
      
    </div>
</footer>
</div>

<!-- Javascript files -->
<!-- jQuery -->
<script src="<?= base_url("assets/theme/") ?>js/jquery.js"></script>
<!-- Bootstrap JS -->
<script src="<?= base_url("assets/theme/") ?>js/bootstrap.min.js"></script>
<!-- Respond JS for IE8 -->
<script src="<?= base_url("assets/theme/") ?>js/respond.min.js"></script>
<!-- HTML5 Support for IE -->
<script src="<?= base_url("assets/theme/") ?>js/html5shiv.js"></script>
<!-- Custom JS -->
<script src="<?= base_url("assets/theme/") ?>js/custom.js"></script>
</body>

</html>